package com.kms.rekofilm.reko_film

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
