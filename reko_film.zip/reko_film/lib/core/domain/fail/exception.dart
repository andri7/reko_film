class ServerException implements Exception {}

class SharedPreferenceException implements Exception {}

class DatabaseException implements Exception {}

class MiddlewareException implements Exception {}
