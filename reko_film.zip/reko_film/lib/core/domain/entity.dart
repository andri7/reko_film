abstract class IEntity {}
