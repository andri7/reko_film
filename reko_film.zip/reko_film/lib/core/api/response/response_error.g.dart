// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'response_error.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ResponseError _$$_ResponseErrorFromJson(Map<String, dynamic> json) =>
    _$_ResponseError(
      message: json['message'] as String,
      status: json['status'] as String,
    );

Map<String, dynamic> _$$_ResponseErrorToJson(_$_ResponseError instance) =>
    <String, dynamic>{
      'message': instance.message,
      'status': instance.status,
    };
