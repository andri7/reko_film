//auth
const login ='/login';
const register ='/register';

//movie
const movie ='/movie';
const detail ='/detail';
const movieDetail = movie + detail;

//error
const error = '/error';